package Web;

import com.eoi.conexion.conexion;
import com.eoi.esctructura.Formulario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/servletadmin")
public class servletadminyuser extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Formulario loginadmin = new Formulario();
        String login1= null;
        String user = request.getParameter("dni");
        String pass = request.getParameter("password");
        
        loginadmin.setDni(user);
        loginadmin.setContrasenya(pass);
        
        System.out.println(loginadmin.getDni());
        System.out.println(loginadmin.getContrasenya());
        
        conexion con = new conexion();
        
        login1 = con.admin(loginadmin);
        System.out.println(login1);
        if(login1 == null){
           response.sendRedirect("paginaPrincipal.html");
           
        }else{
            if (login1.equals("admin")) {
                response.sendRedirect("menuAdministrador.html");
            } else if (login1.equals("user")) {
                response.sendRedirect("datosCliente.jsp");
            
            }
            
        }


    }
    
    
    
    //----------------------------------------------------------------------------
    
    
    
    

   

}
