function validacionInicioSesion() {

    //validar DNI / NIE
    valor = document.getElementById("dniLI").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
    alert('El campo DNI / NIE no puede estar vacío');
    return false;
}
    //validar Contraseña
    valor = document.getElementById("campo").value;
    if( valor == null || valor.length == 0 || /^\s+$/.test(valor) ) {
    alert('El campo contraseña no puede estar vacío o es incorrecto')
    return false;
  }
  
}
