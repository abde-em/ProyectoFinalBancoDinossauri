package com.eoi.conexion;


import com.eoi.esctructura.Formulario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class conexion {
    
    private Connection openConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/banco?useSSL=false&serverTimezone=UTC";
        String user = "root";
        String pass = "Abde.123";
        try{
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                System.out.println("Error al registrar el driver de MySQL: " + ex);
            }
        return DriverManager.getConnection(url, user, pass);
    }  
    
    
    
    public boolean create(Formulario formu) {
        int numRegAfectados;
        String insertQuery = "INSERT INTO cliente(nombre, apellido1,apellido2,dni,telefono, email,calle,numero, piso, poblacion, fechanac, cp, contrasenya,rol) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        Connection con;
        PreparedStatement stmt;
        try {
            con = openConnection();
            stmt = con.prepareStatement(insertQuery);
            stmt.setString(1, formu.getNombre());
            stmt.setString(2, formu.getApellido1());
            stmt.setString(3, formu.getApellido2());
            stmt.setString(4, formu.getDni());
            stmt.setString(5, formu.getTelefono());
            stmt.setString(6, formu.getEmail());
            stmt.setString(7, formu.getCalle());
            stmt.setString(8, formu.getNumero());
            stmt.setString(9, formu.getPiso());
            stmt.setString(10, formu.getPoblacion());
            stmt.setString(11, formu.getFechanac());
            stmt.setString(12, formu.getCp());
            stmt.setString(13, formu.getContrasenya());
            stmt.setString(14, "user");
            System.out.println("Ejecutando la query: " + insertQuery);
            
            		    	
            numRegAfectados = stmt.executeUpdate();
            System.out.println("Registros afectados: " + numRegAfectados);
            stmt.close();
            stmt.close();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }
    

    
    //---------------------------------------------------------------------------------------

    //---------------------------------------------------------------------------------------
    
    public boolean consultaSaldo(int dni) {
        int numRegAfectados;
        String selectQuery = "SELECT saldo FROM cuenta WHERE dni = ?";
        Connection con;
        PreparedStatement stmt;
        ResultSet rs;
        String datos;
        try {
            con = openConnection();
            stmt = con.prepareStatement(selectQuery);
            stmt.setInt(1, dni );
            
            System.out.println("Ejecutando la query: " + selectQuery);
            
            rs = stmt.executeQuery();        // Get the result table from the query  3 
            while (rs.next()) {               // Posiciona el cursor sobre toda la fila
             datos = rs.getString(1);        // Recuperar el valor de la primera 
             datos = rs.getString(2);
             datos = rs.getString(3);
             datos = rs.getString(4);
             datos = rs.getString(5);
             datos = rs.getString(6);
             datos = rs.getString(7);
             datos = rs.getString(8);
             datos = rs.getString(9);
             datos = rs.getString(10);
             datos = rs.getString(11);
             datos = rs.getString(12);
             datos = rs.getString(13);
             datos = rs.getString(14);
             System.out.println("Employee saldo = " + datos);
                                              // Print the column values
            }
            rs.close();  
            
            stmt.close();
            con.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    /*public void consultaSaldos() {
        int numRegAfectados;
        String selectQuery = "SELECT * FROM cuenta";
        Connection con;
        PreparedStatement stmt;
        ResultSet rs;
        String saldo;
        String datos[] = new String[200];
        String dni[] = new String[200];
        int i = 0;
        try {
            con = openConnection();
            stmt = con.prepareStatement(selectQuery);
            
            System.out.println("Ejecutando la query: " + selectQuery);
            
            rs = stmt.executeQuery();        // Get the result table from the query  3 
            while (rs.next()) {               // Posiciona el cursor sobre toda la fila
             datos[i] = rs.getString(1);        // Recuperar el valor de la primera 
             idclientes[i] = rs.getString(2);        // Recuperar el valor de la segunda 
             
             System.out.println("Saldo = " + saldos[i]);
             System.out.println("IDCliente = " + idclientes[i]);

             i++;
            }
            rs.close();  
            
            stmt.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    
    //--------------------------------------------------------------------------------------------------------------------
   /* public boolean consultar(Formulario usuario){
        String consultQuery = "select * from cliente where dni=? and contrasenya=?";
        Connection conexion = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        
        try {
            conexion = openConnection();
            st = conexion.prepareStatement(consultQuery);
            st.setString(1, usuario.getDni());
            st.setString(2, usuario.getContrasenya());
            rs= st.executeQuery();
            if (rs.next()) {
                System.out.println("entro aqui");
            st.close();
            conexion.close();
                return true;
            }
            st.close();
            conexion.close();
            return false;
            
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        
    }*/
    
        public void consultaDatos() {
        int numRegAfectados;
        String selectQuery = "SELECT * FROM cuenta where dni=?";
        Connection con;
        PreparedStatement stmt;
        ResultSet rs;
        String saldo;
        String saldos[] = new String[200];
        String idclientes[] = new String[200];
        int i = 0;
        try {
            con = openConnection();
            stmt = con.prepareStatement(selectQuery);
            
            System.out.println("Ejecutando la query: " + selectQuery);
            
            rs = stmt.executeQuery();        // Get the result table from the query  3 
            while (rs.next()) {               // Posiciona el cursor sobre toda la fila
             saldos[i] = rs.getString(1);        // Recuperar el valor de la primera 
             idclientes[i] = rs.getString(2);        // Recuperar el valor de la segunda 
             
             System.out.println("Saldo = " + saldos[i]);
             System.out.println("IDCliente = " + idclientes[i]);

             i++;
            }
            rs.close();  
            
            stmt.close();
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //-----------------------------------------------------------------------------------------------------------------------
        public String admin(Formulario admin){
        String consultQuery = "select * from cliente where dni=? and contrasenya=?";
        Connection conexion = null;
        PreparedStatement st = null;
        ResultSet rs = null;
        String rol= null;
        try {
            conexion = openConnection();
            st = conexion.prepareStatement(consultQuery);
            st.setString(1, admin.getDni());
            st.setString(2, admin.getContrasenya());
            rs= st.executeQuery();
            
            if (rs.next()) {
                
               rol = rs.getString("rol");
                
                System.out.println("entro aqui");
            st.close();
            conexion.close();
                return rol;
            }
            st.close();
            conexion.close();
            return rol;
            
            
        } catch (SQLException e) {
            e.printStackTrace();
            return rol;
        }
        
    }

    
    
    
            
}
